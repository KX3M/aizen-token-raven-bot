### <h1>ADVANCE FILE SHARE BOT V5 🤖</h1>
<img src="https://telegra.ph/file/e292b12890b8b4b9dcbd1.jpg">
<blockquote><b>THIS IS AN ADVANCE FILE SHARING BOT WITH TOKEN VERIFICATION SYSTEM AND LINK BYPASS DETECTION, MADE BY ➪ <br><a href="https://t.me/Urr_Sanjiii">𝐒ᴀɴJɪ 𝐒ᴀᴍᴀ</a> & <a href="https://t.me/metaui">📚 𝐇 𝐀 𝐌 𝐙 𝐀</a><br> HERE ONLY THE HIGHLIGHTED FEATURES ARE MENTIONED BELOW ;</b></blockquote>

<img src="https://user-images.githubusercontent.com/73097560/115834477-dbab4500-a447-11eb-908a-139a6edaec5c.gif">

> [!CAUTION]
> _```Only true warriors honor their sensei. Keep the credits, and stay on the right path! ⚡🏯```_

<details>
<summary><b><blockquote> BOT'S HIGHLIGHTED FEATURES :</blockquote></b></summary>
  <img align="" alt="count" src="https://count.getloli.com/get/@:otterai?theme=rule34">
  
### <h2> 🌟 BOT FEATURES 1.1: </h2>
<img src="https://user-images.githubusercontent.com/73097560/115834477-dbab4500-a447-11eb-908a-139a6edaec5c.gif"><br>
### 1. FORCE-SUB 📢: 
<i>You can add one or multiple force-sub channels—there's no limit to the number you can add. You can also empty the list by deleting all force-sub channels. This feature provides versatility, allowing you to create a custom number of force-sub channels according to your preference.</i>

### 1.1. REQUEST FORCE-SUB 📢: 
<i>The most demanding aspect is the Request Force-Sub feature. By enabling Request Force-Sub mode, users are provided with a private channel link along with a join request. This feature adds versatility, allowing for greater flexibility in managing Force-Sub channels based on individual preferences. Additionally, the Request Force-Sub settings offer interactive features that enable more advanced and reliable operations.</i>

### 2. ADMINS 👮🏻‍♂️: 
<i>You can add one or multiple admins by providing their user IDs, and you can also remove all admins if needed. Admins have access to some useful bot commands but do not have access to all commands.</i>

### 3. BAN 🚫: 
<i>You can add user IDs to a banned list, preventing those who annoy you or spam the bot from using it. They will be unable to access the bot until you remove them from the banned list.</i>

### 4. AUTO-DELETE 🗑⏱: 
<i>This feature is crucial for protecting the bot from copyright strikes and reducing the risk of being banned from Telegram. It includes two options: first, you can enable or disable the auto-delete mode; second, you can set a timer, so files will be automatically deleted after a specified period. After that it also send a message that shows the "previous message was deleted" and provide the link to retrieve again the same files.</i>

### 5. CONTENT BUTTON ⚪️: 
<i>This feature allows you to add customizable buttons to files shared by the bot. Every file shared by the bot will have a button, which you can tailor to meet your specific needs.</i>

### 6. SET BUTTON 🔘: 
<i>This feature allows you to customize the content buttons on files shared by the bot. For example, you can set the button name and link. You could create a button labeled "Join Channel," which will appear on the files and contain a specific link provided by you.</i>

### 7. HIDE CAPTION & PROTECT CONTENT 🫥🔒:
<i>The "Hide Caption" feature allows you to remove the caption from shared files, while the "Protect Content" feature secures the files. If you enable "Protect Content," the files cannot be forwarded by users.</i>

### 8. DATABASE 💾:
<i>All the features mentioned above are stored permanently in the database, meaning the data will remain unchanged until you decide to modify it.</i>

### 9. TOKEN VERIFICATION 💸: 
<i>You can add or remove token verfication system by providing the required details like shortner url/api key/token timer/etc through bot, and you can also remove/turn off token verification if needed.</i>

### 10. LINK BYPASS DETECTION : 
<i>If a bot user try to bypass the token verification, then the bot will immediately detect it and give a warning to the user and says to verify again. Isn't it Good ?</i>

### 11. BROADCAST WITH PREMIUM EMOJIS : 
<i>If you want to do promo the new feature is for you for sure you will like it. Just Send the msg that you wanna broadcast with premium emojis and reply that msg with /fcast you will se the magic 🪄</i>

### <i>🚀 In addition to the above, more user-friendly and advanced interaction features have been added. It is upgraded version of previous bot features, So more interactive then previous.</i>

</details>

<img src="https://user-images.githubusercontent.com/73097560/115834477-dbab4500-a447-11eb-908a-139a6edaec5c.gif">

### <h2>⚠️ YOU SHOULD ADD BELOW COMMANDS ON YOUR BOT:</h2>
```
start - Ah, checking if I'm alive? How thoughtful of you. 
search - Search For An Anime , ! /search anime name 
top - See Today's Top Animes List
weekly - See Weekly Top Animes List 
batch - Generating multiple links at once? Efficient and clever.  
genlink - A link for a single post? How neat.  
fcast - Broadcast A Message With Forward Tag and Premium Emojis
broadcast - A message for everyone? How bold of you.  
cancel - Ah, stopping a broadcast? Second thoughts, I see.
help - Need a little guidance? Let me show you the way.
users - Curious about user commands? Go on, take a look.  
forcesub - A little rule to ensure everyone stays together.  
req_fsub - Want to know about the requested force subscription? How diligent. 
files - Ah, organizing messages and files? Such a responsible one.  
auto_del - Let’s make things vanish, shall we?  
cmd - A secret list of commands… but only for admins, how exclusive.  
add_fsub - Adding a forced subscription? Such authority you have.  
del_fsub - Removing a forced subscription? A change of heart, perhaps?  
fsub_chnl - Ah, checking the force subscription channels? How meticulous.  
add_admins - Giving admin privileges? How generous of you.  
del_admins - Taking away admin status? A rather cold decision.  
admin_list - Curious about who holds power? Here’s the list.  
add_banuser - Banning someone? My, how merciless.  
del_banuser - Undoing a ban? Feeling kind today?  
banuser_list - A little list of those cast aside. How sad.  
status - Checking my uptime and users? How very observant.  
token - Verifying tokens? Always so careful, aren't you?
restart - Restarting me? Do be gentle.   
```
<img src="https://user-images.githubusercontent.com/73097560/115834477-dbab4500-a447-11eb-908a-139a6edaec5c.gif">

<h2>🧑‍💻 DEVELOPER : 
  <a href="https://t.me/Urr_Sanjiii">𝐒ᴀɴJɪ 𝐒αᴍᴀ</a> & <a href="https://t.me/metaui">📚 𝐇 𝐀 𝐌 𝐙 𝐀</a></h2>



